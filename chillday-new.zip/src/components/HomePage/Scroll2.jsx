import React from 'react'

const Scroll2 = () => {
  return (
    <section className="sec hm-sec-3">
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-lg-8 col-12">
                    <h2 className="sec-head">
                        Choose Your Chill: <br className="d-sm-block d-none" />
                        Discover spots to unwind and enjoy
                    </h2>
                </div>
            </div>
        </div>
    </section>
  )
}

export default Scroll2